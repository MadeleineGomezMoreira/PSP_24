package com.teams.graphql_server_teams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphqlServerTeamsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphqlServerTeamsApplication.class, args);
	}

}
