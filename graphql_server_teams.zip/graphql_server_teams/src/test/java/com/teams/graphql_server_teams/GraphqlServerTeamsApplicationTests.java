package com.teams.graphql_server_teams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlServerTeamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
